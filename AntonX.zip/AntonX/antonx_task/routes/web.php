<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::post('create', 'ProductsController@create');
Route::get('/retrieve','ProductsController@index');
Route::get('/product','ProductsController@store');
Route::get('delete/{product_id}','ProductsController@destroy');
Route::post('edit/{id}','ProductsController@edit');
Route::get('edit/{id}','ProductsController@show');

Route::get('/home', 'HomeController@index')->name('home');
