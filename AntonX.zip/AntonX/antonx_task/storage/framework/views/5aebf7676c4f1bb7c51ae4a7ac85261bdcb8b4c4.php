<?php $__env->startSection('content'); ?>

<head>
<title>View Products Records</title>
</head>
<body>
	 <center>
        <h2>All Products</h2>
<table border = "2" width="50%">
<tr>
<th>Id</th>	
<th>Title</th>
<th>Price</th>
<th>Image</th>
<th>User Id</th>
<th>Update</th>
<th>Remove</th>
</tr>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($product->product_id); ?></td>
<td><?php echo e($product -> title); ?></td>
<td><?php echo e($product -> price); ?></td>
<td><?php echo e($product -> image); ?></td>
<td><?php echo e($product -> user_id); ?></td>
<td><a href = 'edit/<?php echo e($product->product_id); ?>'>Edit</a></td>
<td><a href = 'delete/<?php echo e($product->product_id); ?>'>Delete</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>