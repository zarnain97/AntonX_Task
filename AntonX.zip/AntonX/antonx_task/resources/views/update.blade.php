@extends('layouts.app')

@section('content')

<head>
<title>Update</title>
</head>
<body>
	<center>
		 <h2>Update Product</h2>
<form action = "/edit/<?php echo $products[0]->product_id; ?>" method = "post">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<table>
<tr>
<td>Title</td>
<td>
<input type = 'text' name = 'title'
value = '<?php echo$products[0]->title; ?>'/> </td>
</tr>
<tr>
<td>Price</td>
<td>
<input type = 'text' name = 'price'
value = '<?php echo$products[0]->price; ?>'/>
</td>
</tr>
<tr>
<td>Image</td>
<td>
<input type = 'file' name = 'image'
value = '<?php echo$products[0]->image; ?>'/>
</td>
</tr>

<tr>
<td colspan = '2'>
<input type = 'submit' value = "Update Product" />
</td>
</tr>
</table>
</form>
</body>
</center>
@endsection