@extends('layouts.app')

@section('content')

<head>
<title>View Products Records</title>
</head>
<body>
	 <center>
        <h2>All Products</h2>
<table border = "2" width="50%">
<tr>
<th>Id</th>	
<th>Title</th>
<th>Price</th>
<th>Image</th>
</tr>
@foreach ($products as $product)
<tr>
<td>{{ $product->product_id }}</td>
<td>{{ $product -> title}}</td>
<td>{{ $product -> price}}</td>
<td>{{ $product -> image }}</td>
</tr>
@endforeach
</table>
</body>
</center>
@endsection