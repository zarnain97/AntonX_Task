@extends('layouts.app')

@section('content')

<head>
<title>View Products Records</title>
</head>
<body>
	 <center>
        <h2>All Products</h2>
<table border = "2" width="50%">
<tr>
<th>Id</th>	
<th>Title</th>
<th>Price</th>
<th>Image</th>
<th>User Id</th>
<th>Update</th>
<th>Remove</th>
</tr>
@foreach ($products as $product)
<tr>
<td>{{ $product->product_id }}</td>
<td>{{ $product -> title}}</td>
<td>{{ $product -> price}}</td>
<td>{{ $product -> image }}</td>
<td>{{ $product -> user_id }}</td>
<td><a href = 'edit/{{ $product->product_id }}'>Edit</a></td>
<td><a href = 'delete/{{ $product->product_id }}'>Delete</a></td>
</tr>
@endforeach
</table>
</body>
</center>
@endsection