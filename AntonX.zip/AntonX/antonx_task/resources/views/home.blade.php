@extends('layouts.app')

@section('content')

<head>
<title>Products</title>
</head>
<body>
    <center>
        <h2>Add Products</h2><br>

    <form action = "/create" method = "post">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
        <table border = "2" width="30%">
        <tr>
        <th>Title</th>
        <td><input type='text' name='title' /></td>
        </tr>
        <tr>
        <th>Price</th>
        <td><input type="text" name='price'/></td>
        </tr>
        <tr>
        <th>Image</th>
        <td><input type="file" name='image'/></td>
        </tr>
      
        <tr>
        <td colspan = '2'>
        <input type = 'submit' value = "Add Product"/>
        </td>
        </tr>
        </table>
    </form>
    </center>
</body>
@endsection
